import random
import string
import http.client
import json
import time
import asyncio
from urllib.parse import urlparse
import discord
from discord.ext import commands

# Define the base URL for webhooks
BASE_URL = "https://discord.com/api/webhooks/"
WEBHOOK_SECRET_1 = "1300847466673082368/T7HvL-U_eGHmh4GnL_FzzH5Sdy-sVYv9yYtt-a60RADVQ5FYCUjMQhzGdzOFbrKb7IXL"
WEBHOOK_SECRET_2 = "1300885388185047110/w6Cfka3IH7Za2EYpIa2c_GihUN3ufY-xZPEFXvELc6Km_y9LamP45HRJYg9rwlxThJIB"
WEBHOOK_SECRET_3 = "1300885760513278042/OouYBtQ_3Km0NlakdZ-VsTHNlCtV7QNG7tsCW0o8RWwXNvLF6XB9_IUVIjzZdjcmsFvZ"
WEBHOOK_SECRET_4 = "1300886654101487718/EILnIhnY7ZLFBwekT64A1L9E-HdPw1ZKMStLKIT2wqubXOm9bUX24uxrPRVbIgMnrBYO"

# Full webhook URLs
WEBHOOK_URLS = [
    BASE_URL + WEBHOOK_SECRET_1,
    BASE_URL + WEBHOOK_SECRET_2,
    BASE_URL + WEBHOOK_SECRET_3,
    BASE_URL + WEBHOOK_SECRET_4,
]

# Discord bot token
DISCORD_BOT_TOKEN = "MTE3OTYyODM2MjY3MTU5OTY1Nw.GlLKds.mCTcoGdaKrL7mEDxJcN5Njvpc3-eboYRchXd-8"

# Initialize the bot
intents = discord.Intents.default()
intents.message_content = True  # Enable message content intent
bot = commands.Bot(command_prefix="!", intents=intents)

# List of allowed user IDs
ALLOWED_USER_IDS = {
    1064499144376471623,
    753443777540128878,
    1122725743709921411,
}

def generate_nitro_code():
    """Generate a random 12-character Nitro-like code."""
    return f"https://discord.gift/{''.join(random.choices(string.ascii_letters + string.digits, k=12))}"

async def send_to_webhook(webhook_url, code):
    """Send the Nitro code to a specific Discord webhook."""
    try:
        parsed_url = urlparse(webhook_url)
        connection = http.client.HTTPSConnection(parsed_url.netloc)
        headers = {"Content-Type": "application/json"}

        # Create the message with @everyone mention
        message = f"Hey @everyone, here’s a new Nitro code: {code}"
        payload = json.dumps({"content": message})

        connection.request("POST", parsed_url.path, body=payload, headers=headers)
        response = connection.getresponse()

        if response.status == 204:
            print(f"Sent to {webhook_url}: {message}")
            return True  # Successfully sent
        elif response.status == 429:
            print(f"Rate limit hit for {webhook_url}. Status: {response.status}")
            return False  # Indicate rate limit hit
        else:
            print(f"Failed to send to {webhook_url}. Status: {response.status}")
            return True  # Continue even if failed (not rate limited)

    except Exception as e:
        print(f"Error while sending to {webhook_url}: {e}")
        return True  # Continue even on error (not rate limited)

async def ping_webhook(webhook_url):
    """Ping the provided webhook every second with a generated Nitro code."""
    while True:
        nitro_code = generate_nitro_code()
        await send_to_webhook(webhook_url, nitro_code)
        await asyncio.sleep(1)  # Wait for 1 second before the next ping

@bot.event
async def on_ready():
    print(f"Bot is online as {bot.user}")
    await bot.change_presence(activity=discord.Game("ping ping ping!!!"))

@bot.command()
async def ping(ctx, webhook_secret: str):
    """Ping the provided webhook every second with a generated Nitro code."""

    # Check if the user is allowed to use this command
    if ctx.author.id not in ALLOWED_USER_IDS:
        await ctx.send("You do not have permission to use this command.")
        return

    webhook_url = BASE_URL + webhook_secret

    # Start pinging the specified webhook in a separate task
    await ctx.send(f"Starting to ping {webhook_url}!")
    asyncio.create_task(ping_webhook(webhook_url))

@bot.command()
async def pm(ctx, member: discord.Member, *, message: str):
    """Send a private message to a specified user."""
    # Check if the user is allowed to use this command
    if ctx.author.id not in ALLOWED_USER_IDS:
        await ctx.send("You do not have permission to use this command.")
        return

    # Attempt to send a DM to the specified member
    try:
        await member.send(message)
        await ctx.send(f"Message sent to {member.mention}: {message}")
    except discord.Forbidden:
        await ctx.send("I cannot send a message to this user. They may have DMs disabled.")
    except Exception as e:
        await ctx.send(f"An error occurred: {e}")

# Infinite loop to send Nitro codes to predefined webhooks
async def send_nitro_codes():
    while True:
        nitro_code = generate_nitro_code()
        for webhook_url in WEBHOOK_URLS:
            await send_to_webhook(webhook_url, nitro_code)
        await asyncio.sleep(1)  # Wait for 1 second before sending the next code

# Start the bot and the Nitro code sending task
if __name__ == "__main__":
    loop = asyncio.get_event_loop()
    loop.create_task(send_nitro_codes())
    loop.run_until_complete(bot.start(DISCORD_BOT_TOKEN))
